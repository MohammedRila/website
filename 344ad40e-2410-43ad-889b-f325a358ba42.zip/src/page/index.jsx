import React from 'react';
import './index.css';

export default function Main() {
  return (
    <div className='main-container w-[1920px] h-[4095px] relative mx-auto my-0'>
      <div className='w-[1920px] h-[300px] text-[0px] bg-[#fff] relative overflow-hidden mt-[-90.2px] mr-0 mb-0 ml-[-10px]'>
        <span className="flex w-[878.001px] h-[93px] justify-center items-center font-['Poppins'] text-[62px] font-semibold leading-[93px] text-[#72b37e] relative text-center whitespace-nowrap z-[2] mt-[88.5px] mr-0 mb-0 ml-[521.19px]">
          Turn Your Vision Into Reality
        </span>
        <div className='w-[80px] h-[80px] relative overflow-hidden z-[1] mt-[38.5px] mr-0 mb-0 ml-0' />
      </div>
      <span className="flex w-[913.758px] h-[84px] justify-center items-center font-['Poppins'] text-[56px] font-semibold leading-[84px] text-[#222222] relative text-center whitespace-nowrap z-[4] mt-[150.2px] mr-0 mb-0 ml-[503.31px]">
        Successfully funded campaigns
      </span>
      <div className='w-[1358px] h-[485.2px] relative z-[53] mt-[26.8px] mr-0 mb-0 ml-[281px]'>
        <div className='w-[426px] bg-[#f6d6a2] border-solid border border-[#444444] absolute top-0 bottom-[11.2px] left-1/2 translate-x-[-50%] translate-y-0 shadow-[8px_8px_0_0_rgba(0,0,0,0.25)] z-[29]'>
          <div className='w-[117px] h-[32px] relative overflow-hidden z-[31] mt-[25px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[117px] h-[32px] absolute top-0 left-0 overflow-hidden z-[32]'>
              <div className='w-[117px] h-[32px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[33]'>
                <div className='w-[116px] h-[32px] bg-[url(../assets/images/290987ee-585a-4b0a-aa65-8fb9039ac910.png)] bg-[length:100%_100%] bg-no-repeat relative z-[34] mt-0 mr-0 mb-0 ml-[0.83px]' />
              </div>
            </div>
          </div>
          <div className='w-[376px] h-[190px] bg-[url(../assets/images/5e54b890-f600-4b07-9dc5-583ab77f3eb2.png)] bg-cover bg-no-repeat relative overflow-hidden z-[35] mt-[17px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[191px] h-[96px] relative overflow-hidden z-50 mt-[46px] mr-0 mb-0 ml-[82px]'>
              <div className='w-[191px] h-[96px] absolute top-0 left-0 overflow-hidden z-[51]'>
                <div className='w-[191px] h-[96px] bg-[url(../assets/images/da78d97d-1745-4d74-b556-5fcca9889f14.png)] bg-cover bg-no-repeat absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[52]' />
              </div>
            </div>
          </div>
          <div className='flex w-[376px] h-[29px] justify-between items-center relative z-[41] mt-[17px] mr-0 mb-0 ml-[25px]'>
            <span className="h-[24px] shrink-0 font-['Poppins'] text-[16px] font-semibold leading-[24px] text-[#222222] relative text-left whitespace-nowrap z-[39]">
              Techlogo Company
            </span>
            <button className='w-[64px] h-[29px] shrink-0 bg-[#fff1dc] rounded-[30px] border-none relative z-[41] pointer'>
              <span className="flex w-[63%] h-[19px] justify-center items-center font-['Outfit'] text-[15.199999809265137px] font-thin leading-[19px] text-[#222222] absolute top-[5px] left-[18.75%] text-center whitespace-nowrap z-[42]">
                CSOP
              </span>
            </button>
          </div>
          <span className="block h-[17px] font-['Outfit'] text-[14px] font-thin leading-[17px] text-[#212529] relative text-left whitespace-nowrap z-40 mt-[-4px] mr-0 mb-0 ml-[25px]">
            Kanakpura, Bengaluru
          </span>
          <span className="flex w-[340.5px] h-[52px] justify-start items-center font-['Outfit'] text-[14px] font-thin leading-[17px] text-[#212529] relative text-left overflow-hidden z-[36] mt-[20px] mr-0 mb-0 ml-[25px]">
            Lorem ipsum dolor set lorem ipsuipsum dolor set lorem
            <br />
            ipsm dolor set lorem ipsum dolor set Lorem ipsum dolor
            <br />
            set lorem i...
          </span>
          <div className='w-[376px] h-[8px] bg-[#00b654] rounded-[20px] relative overflow-hidden z-[37] mt-[21px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[282px] h-[8px] bg-[#28a745] relative overflow-hidden z-[38] mt-0 mr-0 mb-0 ml-0' />
          </div>
          <div className='w-[376.2px] h-[20px] relative z-[48] mt-[3px] mr-0 mb-0 ml-[25px]'>
            <span className="flex h-[20px] justify-start items-center font-['Outfit'] text-[16px] font-thin leading-[15px] text-[#222222] absolute top-0 left-0 text-left whitespace-nowrap z-[44]">
              10,000,000
            </span>
            <span className="flex w-[40.65px] h-[20px] justify-end items-center font-['Outfit'] text-[16px] font-thin leading-[15px] text-[#222222] absolute top-0 right-0 text-right whitespace-nowrap z-[48]">
              2,942
            </span>
            <span className="flex h-[15px] justify-start items-center font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] absolute top-[4px] left-[88.48px] text-left whitespace-nowrap z-[45]">
              
              of 10,000,000
            </span>
          </div>
          <div className='flex w-[376.394px] h-[15px] justify-between items-center relative z-[49] mt-[8px] mr-0 mb-0 ml-[25px]'>
            <span className="h-[15px] shrink-0 font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] relative text-left uppercase whitespace-nowrap z-[46]">
              Raised
            </span>
            <span className="flex w-[63.624px] h-[15px] justify-end items-center shrink-0 font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] relative text-right uppercase whitespace-nowrap z-[49]">
              Investors
            </span>
          </div>
        </div>
        <div className='w-[426px] bg-[#f6d6a2] border-solid border border-[#444444] absolute top-[11.2px] bottom-0 left-1/2 translate-x-[-159.39%] translate-y-0 shadow-[8px_8px_0_0_rgba(0,0,0,0.25)] z-[5]'>
          <div className='w-[117px] h-[32px] relative overflow-hidden z-[7] mt-[25px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[117px] h-[32px] absolute top-0 left-0 overflow-hidden z-[8]'>
              <div className='w-[117px] h-[32px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[9]'>
                <div className='w-[116px] h-[32px] bg-[url(../assets/images/c8ed5acb-9769-4d35-a46b-7a344476cbbc.png)] bg-[length:100%_100%] bg-no-repeat relative z-10 mt-0 mr-0 mb-0 ml-[0.83px]' />
              </div>
            </div>
          </div>
          <div className='w-[376px] h-[190px] bg-[url(../assets/images/9bb55db3-c630-4f0a-bb4c-7ec7db6031a0.png)] bg-cover bg-no-repeat relative overflow-hidden z-[11] mt-[17px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[191px] h-[96px] relative overflow-hidden z-[26] mt-[46px] mr-0 mb-0 ml-[82px]'>
              <div className='w-[191px] h-[96px] absolute top-0 left-0 overflow-hidden z-[27]'>
                <div className='w-[191px] h-[96px] bg-[url(../assets/images/864076d3-d728-4a89-8f26-808bc525e45f.png)] bg-cover bg-no-repeat absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[28]' />
              </div>
            </div>
          </div>
          <div className='flex w-[376px] h-[29px] justify-between items-center relative z-[17] mt-[17px] mr-0 mb-0 ml-[25px]'>
            <span className="h-[24px] shrink-0 font-['Poppins'] text-[16px] font-semibold leading-[24px] text-[#222222] relative text-left whitespace-nowrap z-[15]">
              Techlogo Company
            </span>
            <button className='w-[64px] h-[29px] shrink-0 bg-[#fff1dc] rounded-[30px] border-none relative z-[17] pointer'>
              <span className="flex w-[63%] h-[19px] justify-center items-center font-['Outfit'] text-[15.199999809265137px] font-thin leading-[19px] text-[#222222] absolute top-[5px] left-[18.75%] text-center whitespace-nowrap z-[18]">
                CSOP
              </span>
            </button>
          </div>
          <span className="block h-[17px] font-['Outfit'] text-[14px] font-thin leading-[17px] text-[#212529] relative text-left whitespace-nowrap z-[16] mt-[-4px] mr-0 mb-0 ml-[25px]">
            Kanakpura, Bengaluru
          </span>
          <span className="flex w-[340.5px] h-[52px] justify-start items-center font-['Outfit'] text-[14px] font-thin leading-[17px] text-[#212529] relative text-left overflow-hidden z-[12] mt-[20px] mr-0 mb-0 ml-[25px]">
            Lorem ipsum dolor set lorem ipsuipsum dolor set lorem
            <br />
            ipsm dolor set lorem ipsum dolor set Lorem ipsum dolor
            <br />
            set lorem i...
          </span>
          <div className='w-[376px] h-[8px] bg-[#00b654] rounded-[20px] relative overflow-hidden z-[13] mt-[21px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[282px] h-[8px] bg-[#28a745] relative overflow-hidden z-[14] mt-0 mr-0 mb-0 ml-0' />
          </div>
          <div className='w-[376.2px] h-[20px] relative z-[24] mt-[3px] mr-0 mb-0 ml-[25px]'>
            <span className="flex h-[20px] justify-start items-center font-['Outfit'] text-[16px] font-thin leading-[15px] text-[#222222] absolute top-0 left-0 text-left whitespace-nowrap z-20">
              10,000,000
            </span>
            <span className="flex w-[40.65px] h-[20px] justify-end items-center font-['Outfit'] text-[16px] font-thin leading-[15px] text-[#222222] absolute top-0 right-0 text-right whitespace-nowrap z-[24]">
              2,942
            </span>
            <span className="flex h-[15px] justify-start items-center font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] absolute top-[4px] left-[88.48px] text-left whitespace-nowrap z-[21]">
              
              of 10,000,000
            </span>
          </div>
          <div className='flex w-[376.394px] h-[15px] justify-between items-center relative z-[25] mt-[8px] mr-0 mb-0 ml-[25px]'>
            <span className="h-[15px] shrink-0 font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] relative text-left uppercase whitespace-nowrap z-[22]">
              Raised
            </span>
            <span className="flex w-[63.624px] h-[15px] justify-end items-center shrink-0 font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] relative text-right uppercase whitespace-nowrap z-[25]">
              Investors
            </span>
          </div>
        </div>
        <div className='w-[426px] bg-[#f6d6a2] border-solid border border-[#444444] absolute top-[11.2px] bottom-0 left-1/2 translate-x-[59.39%] translate-y-0 shadow-[8px_8px_0_0_rgba(0,0,0,0.25)] z-[53]'>
          <div className='w-[117px] h-[32px] relative overflow-hidden z-[55] mt-[25px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[117px] h-[32px] absolute top-0 left-0 overflow-hidden z-[56]'>
              <div className='w-[117px] h-[32px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[57]'>
                <div className='w-[116px] h-[32px] bg-[url(../assets/images/445a47df-de51-4dd9-99fb-d7f83ae924e0.png)] bg-[length:100%_100%] bg-no-repeat relative z-[58] mt-0 mr-0 mb-0 ml-[0.83px]' />
              </div>
            </div>
          </div>
          <div className='w-[376px] h-[190px] bg-[url(../assets/images/e5794ad7-4e4d-47c0-bbec-a22bad3913e3.png)] bg-cover bg-no-repeat relative overflow-hidden z-[59] mt-[17px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[191px] h-[96px] relative overflow-hidden z-[74] mt-[46px] mr-0 mb-0 ml-[82px]'>
              <div className='w-[191px] h-[96px] absolute top-0 left-0 overflow-hidden z-[75]'>
                <div className='w-[191px] h-[96px] bg-[url(../assets/images/981f6b8a-5fad-4422-bd4f-4cc54efa61b2.png)] bg-cover bg-no-repeat absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[76]' />
              </div>
            </div>
          </div>
          <div className='flex w-[376px] h-[29px] justify-between items-center relative z-[65] mt-[17px] mr-0 mb-0 ml-[25px]'>
            <span className="h-[24px] shrink-0 font-['Poppins'] text-[16px] font-semibold leading-[24px] text-[#222222] relative text-left whitespace-nowrap z-[63]">
              Techlogo Company
            </span>
            <button className='w-[64px] h-[29px] shrink-0 bg-[#fff1dc] rounded-[30px] border-none relative z-[65] pointer'>
              <span className="flex w-[63%] h-[19px] justify-center items-center font-['Outfit'] text-[15.199999809265137px] font-thin leading-[19px] text-[#222222] absolute top-[5px] left-[18.75%] text-center whitespace-nowrap z-[66]">
                CSOP
              </span>
            </button>
          </div>
          <span className="block h-[17px] font-['Outfit'] text-[14px] font-thin leading-[17px] text-[#212529] relative text-left whitespace-nowrap z-[64] mt-[-4px] mr-0 mb-0 ml-[25px]">
            Kanakpura, Bengaluru
          </span>
          <span className="flex w-[340.5px] h-[52px] justify-start items-center font-['Outfit'] text-[14px] font-thin leading-[17px] text-[#212529] relative text-left overflow-hidden z-[60] mt-[20px] mr-0 mb-0 ml-[25px]">
            Lorem ipsum dolor set lorem ipsuipsum dolor set lorem
            <br />
            ipsm dolor set lorem ipsum dolor set Lorem ipsum dolor
            <br />
            set lorem i...
          </span>
          <div className='w-[376px] h-[8px] bg-[#00b654] rounded-[20px] relative overflow-hidden z-[61] mt-[21px] mr-0 mb-0 ml-[25px]'>
            <div className='w-[282px] h-[8px] bg-[#28a745] relative overflow-hidden z-[62] mt-0 mr-0 mb-0 ml-0' />
          </div>
          <div className='w-[376.2px] h-[20px] relative z-[72] mt-[3px] mr-0 mb-0 ml-[25px]'>
            <span className="flex h-[20px] justify-start items-center font-['Outfit'] text-[16px] font-thin leading-[15px] text-[#222222] absolute top-0 left-0 text-left whitespace-nowrap z-[68]">
              10,000,000
            </span>
            <span className="flex w-[40.65px] h-[20px] justify-end items-center font-['Outfit'] text-[16px] font-thin leading-[15px] text-[#222222] absolute top-0 right-0 text-right whitespace-nowrap z-[72]">
              2,942
            </span>
            <span className="flex h-[15px] justify-start items-center font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] absolute top-[4px] left-[88.48px] text-left whitespace-nowrap z-[69]">
              
              of 10,000,000
            </span>
          </div>
          <div className='flex w-[376.394px] h-[15px] justify-between items-center relative z-[73] mt-[8px] mr-0 mb-0 ml-[25px]'>
            <span className="h-[15px] shrink-0 font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] relative text-left uppercase whitespace-nowrap z-[70]">
              Raised
            </span>
            <span className="flex w-[63.624px] h-[15px] justify-end items-center shrink-0 font-['Outfit'] text-[12px] font-thin leading-[15px] text-[#212529] relative text-right uppercase whitespace-nowrap z-[73]">
              Investors
            </span>
          </div>
        </div>
      </div>
      <button className='flex w-[210px] h-[48px] pt-[17px] pr-[23px] pb-[17px] pl-[23px] justify-center items-center flex-nowrap bg-[#72b37e] rounded-[8px] border-none relative z-[77] pointer mt-[63.8px] mr-0 mb-0 ml-[851px]'>
        <span className="flex w-[89px] h-[14px] justify-center items-center shrink-0 basis-auto font-['Inter'] text-[14px] font-normal leading-[14px] text-[#fff] relative text-center whitespace-nowrap z-[78]">
          Register Now
        </span>
      </button>
      <div className='w-[1920px] h-[640px] bg-[#d9d9c9] relative z-[79] mt-[120.2px] mr-0 mb-0 ml-0'>
        <div className='w-[1406px] h-[234.2px] relative z-[86] mt-[119.8px] mr-0 mb-0 ml-[295px]'>
          <div className='w-[313px] h-[188px] bg-[url(../assets/images/e84efecf-543f-4729-a1a5-9ac8fb753baa.png)] bg-cover bg-no-repeat absolute top-0 left-[670px] z-[85]'>
            <div className='w-[49px] h-[48px] relative overflow-hidden z-[89] mt-[30px] mr-0 mb-0 ml-[28px]'>
              <div className='w-[49px] h-[48px] absolute top-0 left-0 overflow-hidden z-[90]'>
                <div className='w-[49px] h-[48px] bg-[url(../assets/images/607cc949-4a67-461b-b6d0-25d91b019ec4.png)] bg-cover bg-no-repeat absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[91]' />
              </div>
            </div>
            <span className="block h-[30px] font-['Poppins'] text-[20px] font-semibold leading-[30px] text-[#222222] relative text-left whitespace-nowrap z-[92] mt-px mr-0 mb-0 ml-[32px]">
              Strategic Guidance
            </span>
            <span className="flex w-[211.18px] h-[44px] justify-start items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#222222] relative text-left z-[93] mt-px mr-0 mb-0 ml-[26px]">
              Get highlighted on community
              <br />
              engagement
            </span>
          </div>
          <div className='w-[313px] h-[188px] bg-[url(../assets/images/3de3d946-1ccc-499c-815e-ec52d8103440.png)] bg-cover bg-no-repeat absolute top-0 left-[1093px] z-[86]'>
            <div className='w-[49px] h-[48px] relative overflow-hidden z-[94] mt-[27px] mr-0 mb-0 ml-[22px]'>
              <div className='w-[49px] h-[48px] absolute top-0 left-0 overflow-hidden z-[95]'>
                <div className='w-[49px] h-[48px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[96]'>
                  <div className='w-[48px] h-[48px] bg-[url(../assets/images/b3b99bbe-e5f4-4c3f-939c-391596b9a807.png)] bg-[length:100%_100%] bg-no-repeat relative z-[97] mt-0 mr-0 mb-0 ml-[0.5px]' />
                </div>
              </div>
            </div>
            <span className="block h-[30px] font-['Poppins'] text-[20px] font-semibold leading-[30px] text-[#fff] relative text-left whitespace-nowrap z-[98] mt-[2px] mr-0 mb-0 ml-[16px]">
              Transparent Process
            </span>
            <span className="flex w-[232.15px] h-[44px] justify-start items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] relative text-left z-[99] mt-[6px] mr-0 mb-0 ml-[16px]">
              Easy and transparent process to
              <br />
              access capital through campaign
            </span>
          </div>
          <span className="flex w-[564.01px] h-[163px] justify-start items-center font-['Poppins'] text-[56px] font-semibold leading-[84px] text-[#222222] absolute top-[71.2px] left-0 right-[841.99px] text-left z-[82]">
            Unique Advantages
            <br />
            for Startups
          </span>
        </div>
        <div className='w-[1406px] h-[200px] relative z-[88] mt-[14.8px] mr-0 mb-0 ml-[295px]'>
          <button className='flex w-[210px] h-[48px] pt-[17px] pr-[23px] pb-[17px] pl-[23px] justify-center items-center flex-nowrap bg-[#72b37e] rounded-[8px] border-none absolute top-1/2 left-0 translate-x-0 translate-y-[-208.33%] z-[83] pointer'>
            <span className="flex w-[89px] h-[14px] justify-center items-center shrink-0 basis-auto font-['Inter'] text-[14px] font-normal leading-[14px] text-[#fff] relative text-center whitespace-nowrap z-[84]">
              Register Now
            </span>
          </button>
          <div className='w-[313px] h-[188px] bg-[url(../assets/images/b6f16546-bea9-4685-a30d-7ccb804ab386.png)] bg-cover bg-no-repeat absolute top-[12px] left-[670px] z-[88]'>
            <div className='w-[49px] h-[48px] relative overflow-hidden z-[100] mt-[22px] mr-0 mb-0 ml-[13px]'>
              <div className='w-[49px] h-[48px] absolute top-0 left-0 overflow-hidden z-[101]'>
                <div className='w-[49px] h-[48px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[102]'>
                  <div className='w-[37.5px] h-[48px] bg-[url(../assets/images/f098a46a-b2a3-4843-85d2-303d3e526cf2.png)] bg-[length:100%_100%] bg-no-repeat relative z-[103] mt-0 mr-0 mb-0 ml-[5.75px]' />
                </div>
              </div>
            </div>
            <span className="block h-[30px] font-['Poppins'] text-[20px] font-semibold leading-[30px] text-[#fff] relative text-left whitespace-nowrap z-[104] mt-[13px] mr-0 mb-0 ml-[16px]">
              Community Support
            </span>
            <span className="flex w-[245.51px] h-[44px] justify-start items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] relative text-left z-[105] mt-px mr-0 mb-0 ml-[13px]">
              Easily accessible to information
              <br />
              through our dedicated founder tab
            </span>
          </div>
          <div className='w-[313px] h-[188px] bg-[url(../assets/images/d696baae-6530-4c3a-97b7-83ba06c2fc89.png)] bg-cover bg-no-repeat absolute top-[12px] left-[1093px] z-[87]'>
            <div className='w-[49px] h-[48px] relative overflow-hidden z-[106] mt-[18px] mr-0 mb-0 ml-[22px]'>
              <div className='w-[49px] h-[48px] absolute top-0 left-0 overflow-hidden z-[107]'>
                <div className='w-[49px] h-[48px] bg-[url(../assets/images/b72c77b7-2b56-42d9-822f-b4acb23fa6eb.png)] bg-cover bg-no-repeat absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[108]' />
              </div>
            </div>
            <span className="block h-[30px] font-['Poppins'] text-[20px] font-semibold leading-[30px] text-[#222222] relative text-left whitespace-nowrap z-[109] mt-[6px] mr-0 mb-0 ml-[12px]">
              Complete Digital Process
            </span>
            <span className="flex w-[216.28px] h-[44px] justify-start items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#222222] relative text-left z-[110] mt-[6px] mr-0 mb-0 ml-[12px]">
              Strategic guidance on business
              <br />
              through expert advice
            </span>
          </div>
        </div>
      </div>
      <div className='w-[1920px] h-[1136px] bg-[#000] relative z-[111] mt-0 mr-0 mb-0 ml-0'>
        <div className="w-[985.7px] h-[163px] font-['Poppins'] text-[56px] font-semibold leading-[84px] relative text-center z-[114] mt-[122px] mr-0 mb-0 ml-[467.25px]">
          <span className="font-['Poppins'] text-[56px] font-semibold leading-[84px] text-[#fff] relative text-center">
            Fuel Your Startup Journey with Our
            <br />
          </span>
          <span className="font-['Poppins'] text-[56px] font-semibold leading-[84px] text-[#72b37e] relative text-center">
            Funding Pathway
          </span>
        </div>
        <div className='flex w-[1082px] h-[92px] justify-between items-center relative z-[150] mt-[90px] mr-0 mb-0 ml-[419px]'>
          <div className='w-[92px] h-[92px] shrink-0 bg-[#f5f5f5] rounded-[46px] border-solid border border-[#fff] relative z-[116]'>
            <div className='w-[41px] h-[40px] relative overflow-hidden z-[117] mt-[26px] mr-0 mb-0 ml-[25.5px]'>
              <div className='w-[41px] h-[40px] absolute top-0 left-0 overflow-hidden z-[118]'>
                <div className='w-[41px] h-[40px] bg-[url(../assets/images/673fe6b2-9bf2-43ed-aed7-7766c248fd63.png)] bg-cover bg-no-repeat absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[119]' />
              </div>
            </div>
          </div>
          <div className='w-[219px] h-[18px] shrink-0 relative overflow-hidden z-[123]'>
            <div className='w-[219px] h-[2.009px] relative overflow-hidden z-[124] mt-[7.996px] mr-0 mb-0 ml-0'>
              <div className='w-[217.996px] h-[2.009px] bg-[url(../assets/images/9eac6e33-c0b6-45a1-962e-364719e79af8.png)] bg-[length:100%_100%] bg-no-repeat relative z-[125] mt-0 mr-0 mb-0 ml-[0.5px]' />
            </div>
          </div>
          <div className='w-[92px] h-[92px] shrink-0 bg-[#f5f5f5] rounded-[46px] border-solid border border-[#fff] relative z-[127]'>
            <div className='w-[41px] h-[40px] relative overflow-hidden z-[128] mt-[26px] mr-0 mb-0 ml-[25.5px]'>
              <div className='w-[41px] h-[40px] absolute top-0 left-0 overflow-hidden z-[129]'>
                <div className='w-[41px] h-[40px] bg-[url(../assets/images/27102f13-a3b5-41c4-8905-56c87944df0d.png)] bg-cover bg-no-repeat absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[130]' />
              </div>
            </div>
          </div>
          <div className='w-[219px] h-[18px] shrink-0 relative overflow-hidden z-[134]'>
            <div className='w-[219px] h-[2.009px] relative overflow-hidden z-[135] mt-[7.996px] mr-0 mb-0 ml-0'>
              <div className='w-[217.996px] h-[2.009px] bg-[url(../assets/images/b6013b1b-3d73-4c17-b90b-b0d34929c54e.png)] bg-[length:100%_100%] bg-no-repeat relative z-[136] mt-0 mr-0 mb-0 ml-[0.5px]' />
            </div>
          </div>
          <div className='w-[92px] h-[92px] shrink-0 bg-[#f4f4f4] rounded-[46px] border-solid border border-[#fff] relative z-[138]'>
            <div className='w-[41px] h-[40px] relative overflow-hidden z-[139] mt-[26px] mr-0 mb-0 ml-[25.5px]'>
              <div className='w-[41px] h-[40px] absolute top-0 left-0 overflow-hidden z-[140]'>
                <div className='w-[41px] h-[40px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[141]'>
                  <div className='w-[35.4px] h-[30.4px] bg-[url(../assets/images/47ea64ed-d63c-411c-9f96-d76c63569559.png)] bg-[length:100%_100%] bg-no-repeat relative z-[142] mt-[4.8px] mr-0 mb-0 ml-[2.8px]' />
                </div>
              </div>
            </div>
          </div>
          <div className='w-[219px] h-[18px] shrink-0 relative overflow-hidden z-[146]'>
            <div className='w-[219px] h-[2.009px] relative overflow-hidden z-[147] mt-[7.996px] mr-0 mb-0 ml-0'>
              <div className='w-[217.996px] h-[2.009px] bg-[url(../assets/images/056e9898-154a-4a65-8142-2eb9474b9462.png)] bg-[length:100%_100%] bg-no-repeat relative z-[148] mt-0 mr-0 mb-0 ml-[0.5px]' />
            </div>
          </div>
          <div className='w-[92px] h-[92px] shrink-0 bg-[#f4f4f4] rounded-[46px] border-solid border border-[#fff] relative z-[150]'>
            <div className='w-[41px] h-[40px] relative overflow-hidden z-[151] mt-[26px] mr-0 mb-0 ml-[25.5px]'>
              <div className='w-[41px] h-[40px] absolute top-0 left-0 overflow-hidden z-[152]'>
                <div className='w-[41px] h-[40px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[153]'>
                  <div className='w-[40px] h-[40px] relative z-[154] mt-0 mr-0 mb-0 ml-[0.5px]'>
                    <div className='w-[39.844px] h-[40px] relative z-[155] mt-0 mr-0 mb-0 ml-[0.08px]'>
                      <div className='w-full h-full bg-[url(../assets/images/1e4c31ce-ae9c-4207-b4ac-5d4e05cc293b.png)] bg-[length:100%_100%] bg-no-repeat absolute top-0 left-0 z-[156]' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='flex w-[1050.46px] h-[30px] justify-between items-center relative z-[157] mt-[24px] mr-0 mb-0 ml-[436.16px]'>
          <span className="flex w-[57.87px] h-[30px] justify-center items-center shrink-0 font-['Outfit'] text-[20px] font-thin leading-[30px] text-[#fff] relative text-center uppercase whitespace-nowrap z-[120]">
            Step 1
          </span>
          <span className="flex w-[61.9px] h-[30px] justify-center items-center shrink-0 font-['Outfit'] text-[19.84375px] font-thin leading-[30px] text-[#fff] relative text-center uppercase whitespace-nowrap z-[131]">
            Step 2
          </span>
          <span className="flex w-[61.81px] h-[30px] justify-center items-center shrink-0 font-['Outfit'] text-[19.84375px] font-thin leading-[30px] text-[#fff] relative text-center uppercase whitespace-nowrap z-[143]">
            Step 3
          </span>
          <span className="flex w-[63.04px] h-[30px] justify-center items-center shrink-0 font-['Outfit'] text-[19.84375px] font-thin leading-[30px] text-[#fff] relative text-center uppercase whitespace-nowrap z-[157]">
            Step 4
          </span>
        </div>
        <div className='w-[1166.015px] h-[46px] relative z-[158] mt-0 mr-0 mb-0 ml-[382.38px]'>
          <span className="flex w-[186.455px] h-[24px] justify-center items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] absolute top-0 left-[calc(50%--396.55px)] text-center whitespace-nowrap z-[158]">
            Founder’s Call & Feedback
          </span>
          <span className="flex w-[165.45px] h-[44px] justify-center items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] absolute top-[2px] left-[calc(50%-583.01px)] text-center z-[121]">
            Submit Pitch Deck With
            <br />
            Application Form
          </span>
          <span className="flex w-[176.09px] h-[44px] justify-center items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] absolute top-[2px] left-[calc(50%-258.34px)] text-center z-[132]">
            Initial Evaluation From IB
            <br />
            Team
          </span>
          <span className="flex w-[151.78px] h-[44px] justify-center items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] absolute top-[2px] left-[calc(50%--83.81px)] text-center z-[144]">
            Financial & Legal Due
            <br />
            Diligence
          </span>
        </div>
        <div className='flex w-[752px] h-[92px] justify-between items-center relative z-[186] mt-[102px] mr-0 mb-0 ml-[584px]'>
          <div className='w-[92px] h-[92px] shrink-0 bg-[#f5f5f5] rounded-[46px] border-solid border border-[#fff] relative z-[160]'>
            <div className='w-[41px] h-[40px] relative overflow-hidden z-[161] mt-[26px] mr-0 mb-0 ml-[25.5px]'>
              <div className='w-[41px] h-[40px] absolute top-0 left-0 overflow-hidden z-[162]'>
                <div className='w-[41px] h-[40px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[163]'>
                  <div className='w-[40px] h-[40px] bg-[url(../assets/images/4e7b2a9c-095d-46ac-bbf1-6d67f04f1188.png)] bg-[length:100%_100%] bg-no-repeat relative z-[164] mt-0 mr-0 mb-0 ml-[0.5px]' />
                </div>
              </div>
            </div>
          </div>
          <div className='w-[219px] h-[18px] shrink-0 relative overflow-hidden z-[168]'>
            <div className='w-[219px] h-[2.009px] relative overflow-hidden z-[169] mt-[7.996px] mr-0 mb-0 ml-0'>
              <div className='w-[217.996px] h-[2.009px] bg-[url(../assets/images/e61a4262-96ae-42f0-8d47-1b5a120c530f.png)] bg-[length:100%_100%] bg-no-repeat relative z-[170] mt-0 mr-0 mb-0 ml-[0.5px]' />
            </div>
          </div>
          <div className='w-[92px] h-[92px] shrink-0 bg-[#f5f5f5] rounded-[46px] border-solid border border-[#fff] relative z-[172]'>
            <div className='w-[41px] h-[40px] relative overflow-hidden z-[173] mt-[26px] mr-0 mb-0 ml-[25.5px]'>
              <div className='w-[41px] h-[40px] absolute top-0 left-0 overflow-hidden z-[174]'>
                <div className='w-[41px] h-[40px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[175]'>
                  <div className='w-[40px] h-[40px] relative z-[176] mt-0 mr-0 mb-0 ml-[0.5px]'>
                    <div className='w-[38.134px] h-[38.067px] relative z-[177] mt-[1.25px] mr-0 mb-0 ml-[0.62px]'>
                      <div className='w-[100.79%] h-[100.79%] bg-[url(../assets/images/89df38bb-fc17-40f8-83e3-6a432b85e4a3.png)] bg-[length:100%_100%] bg-no-repeat absolute top-[-0.39%] left-[-0.4%] z-[178]' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='w-[219px] h-[18px] shrink-0 relative overflow-hidden z-[182]'>
            <div className='w-[219px] h-[2.009px] relative overflow-hidden z-[183] mt-[7.996px] mr-0 mb-0 ml-0'>
              <div className='w-[217.996px] h-[2.009px] bg-[url(../assets/images/d3f08000-a210-4423-ac5c-3b1a11a4d683.png)] bg-[length:100%_100%] bg-no-repeat relative z-[184] mt-0 mr-0 mb-0 ml-[0.5px]' />
            </div>
          </div>
          <div className='w-[92px] h-[92px] shrink-0 bg-[#f5f5f5] rounded-[46px] border-solid border border-[#fff] relative z-[186]'>
            <div className='w-[33px] h-[32px] relative overflow-hidden z-[187] mt-[30px] mr-0 mb-0 ml-[29.5px]'>
              <div className='w-[33px] h-[32px] absolute top-0 left-0 overflow-hidden z-[188]'>
                <div className='w-[33px] h-[32px] absolute top-1/2 left-1/2 translate-x-[-50%] translate-y-[-50%] overflow-hidden z-[189]'>
                  <div className='w-[32px] h-[32px] relative z-[190] mt-0 mr-0 mb-0 ml-[0.5px]'>
                    <div className='w-[31.634px] h-[32px] relative z-[191] mt-0 mr-0 mb-0 ml-[0.18px]'>
                      <div className='w-[100.95%] h-full bg-[url(../assets/images/5b673c19-c2aa-4724-ac63-e12a9aacdf3d.png)] bg-[length:100%_100%] bg-no-repeat absolute top-0 left-[-0.47%] z-[192]' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='flex w-[721.78px] h-[30px] justify-between items-center relative z-[193] mt-[24px] mr-0 mb-0 ml-[599.16px]'>
          <span className="flex w-[61.87px] h-[30px] justify-center items-center shrink-0 font-['Outfit'] text-[19.84375px] font-thin leading-[30px] text-[#fff] relative text-center uppercase whitespace-nowrap z-[165]">
            Step 5
          </span>
          <span className="flex w-[62.4px] h-[30px] justify-center items-center shrink-0 font-['Outfit'] text-[19.84375px] font-thin leading-[30px] text-[#fff] relative text-center uppercase whitespace-nowrap z-[179]">
            Step 6
          </span>
          <span className="flex w-[61.67px] h-[30px] justify-center items-center shrink-0 font-['Outfit'] text-[19.84375px] font-thin leading-[30px] text-[#fff] relative text-center uppercase whitespace-nowrap z-[193]">
            Step 7
          </span>
        </div>
        <div className='w-[844.49px] h-[46px] relative z-[194] mt-0 mr-0 mb-0 ml-[534.91px]'>
          <span className="flex w-[146.674px] h-[24px] justify-center items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] absolute top-0 left-[calc(50%-70.34px)] text-center whitespace-nowrap z-[180]">
            Campaign Goes Live
          </span>
          <span className="flex w-[190.38px] h-[44px] justify-center items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] absolute top-[2px] left-[calc(50%-422.24px)] text-center z-[166]">
            Commitment & Term Sheet
            <br />
            Signing
          </span>
          <span className="flex w-[178.6px] h-[44px] justify-center items-center font-['Outfit'] text-[16px] font-thin leading-[24px] text-[#fff] absolute top-[2px] left-[calc(50%--243.64px)] text-center z-[194]">
            Campaign Closure & Post
            <br />
            Closure Procedure
          </span>
        </div>
        <button className='flex w-[210px] h-[48px] pt-[17px] pr-[23px] pb-[17px] pl-[23px] justify-center items-center flex-nowrap bg-[#72b37e] rounded-[8px] border-none relative z-[195] pointer mt-[106.8px] mr-0 mb-0 ml-[865px]'>
          <span className="flex w-[116px] h-[14px] justify-center items-center shrink-0 basis-auto font-['Inter'] text-[14px] font-normal leading-[14px] text-[#fff] relative text-center whitespace-nowrap z-[196]">
            Start a Campaign
          </span>
        </button>
      </div>
      <div className='w-[1920px] h-[420px] relative overflow-hidden z-[197] mt-0 mr-0 mb-0 ml-0'>
        <div className='w-[1274px] h-[264px] relative z-[200] mt-[78px] mr-0 mb-0 ml-[323px]'>
          <div className='w-[1244px] h-[168px] relative z-[201] mt-0 mr-0 mb-0 ml-[15px]'>
            <span className="flex w-[1054.52px] h-[163px] justify-center items-center font-['Poppins'] text-[56px] font-semibold leading-[84px] text-[#fff] absolute top-[2px] left-[calc(50%-527.16px)] text-center z-[202]">
              Ready for an exciting journey to raise
              <br />
              capital?
            </span>
          </div>
          <button className='flex w-[210px] h-[48px] pt-[17px] pr-[23px] pb-[17px] pl-[23px] justify-center items-center flex-nowrap bg-[#72b37e] rounded-[8px] border-none relative z-[203] pointer mt-[30.8px] mr-0 mb-0 ml-[532px]'>
            <span className="flex w-[89px] h-[14px] justify-center items-center shrink-0 basis-auto font-['Inter'] text-[14px] font-normal leading-[14px] text-[#fff] relative text-center whitespace-nowrap z-[204]">
              Register Now
            </span>
          </button>
        </div>
        <div className='h-full absolute top-0 left-0 right-0 z-[198]'>
          <div className='w-[1920px] h-[420px] bg-[rgba(40,40,39,0.8)] absolute top-0 left-0 z-[199]' />
        </div>
      </div>
      <span className="flex w-[794.165px] h-[84px] justify-center items-center font-['Poppins'] text-[56px] font-semibold leading-[84px] text-[#222222] relative text-center whitespace-nowrap z-[206] mt-[120px] mr-0 mb-0 ml-[563.09px]">
        Frequently Asked Questions
      </span>
      <div className='w-[1840px] h-[392px] bg-[#f4f4f4] relative z-[207] mt-[55px] mr-0 mb-0 ml-[40px]'>
        <div className='w-[1825px] h-[73px] bg-[#f4f4f4] relative overflow-hidden z-[208] mt-[15px] mr-0 mb-0 ml-[15px]'>
          <div className='w-[1688.14px] h-[74px] relative z-[209] mt-0 mr-0 mb-0 ml-[24px]'>
            <span className="flex h-[25px] justify-start items-center font-['Outfit'] text-[20px] font-thin leading-[25px] text-[#222222] absolute top-[24px] left-0 text-left whitespace-nowrap z-[210]">
              1. How can CREDDINV assist my startup in securing funding?
            </span>
            <div className='w-[1.78%] h-[22px] absolute top-1/2 left-[98%] translate-x-0 translate-y-[-56.82%] z-[211]'>
              <div className='w-[30px] h-[22px] absolute top-0 left-0 overflow-hidden z-[212]'>
                <div className='w-[22px] h-[21.241px] relative overflow-hidden z-[213] mt-[0.38px] mr-0 mb-0 ml-[8px]'>
                  <div className='w-[19.724px] h-[19.724px] bg-[url(../assets/images/3748ffa1-d6ec-4f0a-9955-d9786ff48aa3.png)] bg-[length:100%_100%] bg-no-repeat relative z-[214] mt-0 mr-0 mb-0 ml-[0.38px]' />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='w-[1825px] h-[73px] bg-[#f4f4f4] relative overflow-hidden z-[215] mt-0 mr-0 mb-0 ml-[15px]'>
          <div className='w-[1688.14px] h-[74px] relative z-[216] mt-0 mr-0 mb-0 ml-[24px]'>
            <span className="flex h-[25px] justify-start items-center font-['Outfit'] text-[20px] font-thin leading-[25px] text-[#222222] absolute top-[24px] left-0 text-left whitespace-nowrap z-[217]">
              2.What types of funding solutions does CREDDINV offer for startups
              at different stages of growth?
            </span>
            <div className='w-[1.78%] h-[22px] absolute top-1/2 left-[98%] translate-x-0 translate-y-[-56.82%] z-[218]'>
              <div className='w-[30px] h-[22px] absolute top-0 left-0 overflow-hidden z-[219]'>
                <div className='w-[22px] h-[21.241px] relative overflow-hidden z-[220] mt-[0.38px] mr-0 mb-0 ml-[8px]'>
                  <div className='w-[19.724px] h-[19.724px] bg-[url(../assets/images/20b4bd98-8c1b-457c-a43b-78a343eebb14.png)] bg-[length:100%_100%] bg-no-repeat relative z-[221] mt-0 mr-0 mb-0 ml-[0.38px]' />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='w-[1825px] h-[73px] bg-[#f4f4f4] relative overflow-hidden z-[222] mt-0 mr-0 mb-0 ml-[15px]'>
          <div className='w-[1688.14px] h-[74px] relative z-[223] mt-0 mr-0 mb-0 ml-[24px]'>
            <span className="flex h-[25px] justify-start items-center font-['Outfit'] text-[20px] font-thin leading-[25px] text-[#222222] absolute top-[24px] left-0 text-left whitespace-nowrap z-[224]">
              3. How does CREDDINV assess the scalability and market potential
              of startups?
            </span>
            <div className='w-[1.78%] h-[22px] absolute top-1/2 left-[98%] translate-x-0 translate-y-[-56.82%] z-[225]'>
              <div className='w-[30px] h-[22px] absolute top-0 left-0 overflow-hidden z-[226]'>
                <div className='w-[22px] h-[21.241px] relative overflow-hidden z-[227] mt-[0.38px] mr-0 mb-0 ml-[8px]'>
                  <div className='w-[19.724px] h-[19.724px] bg-[url(../assets/images/12b2e1d6-4e61-4de2-a64b-276b7b56a972.png)] bg-[length:100%_100%] bg-no-repeat relative z-[228] mt-0 mr-0 mb-0 ml-[0.38px]' />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='w-[1825px] h-[73px] bg-[#f4f4f4] relative overflow-hidden z-[229] mt-0 mr-0 mb-0 ml-[15px]'>
          <div className='w-[1688.14px] h-[74px] relative z-[230] mt-0 mr-0 mb-0 ml-[24px]'>
            <span className="flex h-[25px] justify-start items-center font-['Outfit'] text-[20px] font-thin leading-[25px] text-[#222222] absolute top-[24px] left-0 text-left whitespace-nowrap z-[231]">
              4. What industries or sectors does CREDDINV specialise in for
              startup investment?
            </span>
            <div className='w-[1.78%] h-[22px] absolute top-1/2 left-[98%] translate-x-0 translate-y-[-56.82%] z-[232]'>
              <div className='w-[30px] h-[22px] absolute top-0 left-0 overflow-hidden z-[233]'>
                <div className='w-[22px] h-[21.241px] relative overflow-hidden z-[234] mt-[0.38px] mr-0 mb-0 ml-[8px]'>
                  <div className='w-[19.724px] h-[19.724px] bg-[url(../assets/images/6cde1681-a0bc-4cd5-ad9a-2a76c7591cb9.png)] bg-[length:100%_100%] bg-no-repeat relative z-[235] mt-0 mr-0 mb-0 ml-[0.38px]' />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='w-[1825px] h-[70px] bg-[#f4f4f4] relative overflow-hidden z-[236] mt-0 mr-0 mb-0 ml-[15px]'>
          <div className='w-[1688.14px] h-[71px] relative z-[237] mt-0 mr-0 mb-0 ml-[24px]'>
            <span className="flex h-[25px] justify-start items-center font-['Outfit'] text-[20px] font-thin leading-[25px] text-[#222222] absolute top-[24px] left-0 text-left whitespace-nowrap z-[238]">
              5. What success stories or case studies can CREDDINV share of
              startups it has supported?
            </span>
            <div className='w-[1.78%] h-[22px] absolute top-1/2 left-[98%] translate-x-0 translate-y-[-50%] z-[239]'>
              <div className='w-[30px] h-[22px] absolute top-0 left-0 overflow-hidden z-[240]'>
                <div className='w-[22px] h-[21.241px] relative overflow-hidden z-[241] mt-[0.38px] mr-0 mb-0 ml-[8px]'>
                  <div className='w-[19.724px] h-[19.724px] bg-[url(../assets/images/c856595a-13d2-4b04-8832-414888006bad.png)] bg-[length:100%_100%] bg-no-repeat relative z-[242] mt-0 mr-0 mb-0 ml-[0.38px]' />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
