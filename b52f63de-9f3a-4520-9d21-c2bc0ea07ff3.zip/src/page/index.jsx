import React from 'react';
import './index.css';

export default function Main() {
  return (
    <div className='main-container'>
      <div className='w-light'>
        <div className='header'>
          <div className='list-margin'>
            <div className='list'>
              <div className='item'>
                <div className='container'>
                  <span className='invest'>Invest</span>
                </div>
              </div>
              <div className='item-1'>
                <div className='link'>
                  <div className='learn'>
                    <span className='learn-2'>Learn</span>
                  </div>
                </div>
              </div>
              <div className='item-3'>
                <div className='link-4'>
                  <span className='about-us'>About Us</span>
                </div>
              </div>
              <div className='item-5'>
                <div className='link-6'>
                  <span className='sign-in'>Sign-In</span>
                </div>
              </div>
            </div>
          </div>
          <div className='link-button'>
            <div className='container-7' />
            <span className='contact'>Contact</span>
          </div>
        </div>
        <span className='investing-made-simple'>Investing Made Simple</span>
        <div className='flex-row-ecbc'>
          <span className='unique-advantages-for-investors'>
            Unique Advantages for Investors
          </span>
          <div className='link-button-8'>
            <span className='start-investing'>Start Investing</span>
          </div>
        </div>
        <div className='flex-row-dd'>
          <div className='background-border-shadow'>
            <div className='icon-transparency-cdefd-svg'>
              <div className='icon-transparency-cdefd-svg-fill'>
                <div className='icon-transparency-cdefd-svg-9' />
              </div>
            </div>
            <span className='complete-digital-process'>
              Complete Digital Process
            </span>
          </div>
          <div className='background-border-shadow-a'>
            <div className='icon-community-ca-svg'>
              <div className='icon-community-ca-svg-fill'>
                <div className='icon-community-ca-svg-b'>
                  <div className='vector' />
                </div>
              </div>
            </div>
            <span className='lower-ticket-size'>Lower Ticket Size</span>
          </div>
          <div className='background-border-shadow-c'>
            <div className='icon-advice-svg'>
              <div className='icon-advice-svg-fill'>
                <div className='icon-advice-svg-d'>
                  <div className='vector-e' />
                </div>
              </div>
            </div>
            <span className='diversification'>Diversification</span>
          </div>
        </div>
        <div className='flex-row-b'>
          <div className='background-border-shadow-f'>
            <div className='icon-stats-ece-svg'>
              <div className='icon-stats-ece-svg-fill'>
                <div className='icon-stats-ece-svg-10'>
                  <div className='clip-path-group' />
                </div>
              </div>
            </div>
            <span className='customised-dashboard'>Customised Dashboard</span>
          </div>
          <div className='background-border-shadow-11'>
            <div className='icon-pitch-da-svg'>
              <div className='icon-pitch-da-svg-fill'>
                <div className='icon-pitch-da-svg-12' />
              </div>
            </div>
            <span className='timely-update-and-reviews'>
              Timely Update and Reviews
            </span>
          </div>
        </div>
        <div className='section'>
          <span className='wealth-calculator'>Wealth Calculator</span>
          <div className='flex-row-d'>
            <div className='container-13'>
              <div className='container-14'>
                <div className='border'>
                  <div className='background'>
                    <div className='image' />
                    <div className='container-15'>
                      <div className='phonepe-logo-ac-svg'>
                        <div className='phonepe-logo-ac-svg-fill'>
                          <div className='phonepe-logo-ac-svg-16'>
                            <div className='clip-path-group-17' />
                          </div>
                        </div>
                      </div>
                      <span className='uphill-valuation-since-mar'>
                        Uphill valuation since Mar 15
                      </span>
                    </div>
                  </div>
                  <div className='background-18'>
                    <div className='phonepe-logo-ac-svg-19'>
                      <div className='phonepe-logo-ac-svg-fill-1a'>
                        <div className='phonepe-logo-ac-svg-1b'>
                          <div className='clip-path-group-1c' />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <span className='phonepe'>PhonePe</span>
                <div className='paragraph'>
                  <span className='a-card-linked-digital-wallet'>
                    A card-linked digital wallet solution for customers,
                    offering UPI-based bill
                  </span>
                  <span className='payments-online-shopping-utility-payments'>
                    payments, online shopping, utility payments, recharges,
                    money transfers, QR cod…
                  </span>
                </div>
                <span className='use-the-slider-below'>
                  Use the slider below for a hypothetical investment amount
                </span>
                <div className='input'>
                  <div className='gradient-shadow' />
                </div>
                <div className='flex-row-d-1d'>
                  <div className='paragraph-background'>
                    <span className='if-invested-mar'>
                      If you had invested (in Mar 15)
                    </span>
                    <span className='rupees'>₹10,000</span>
                  </div>
                  <div className='paragraph-background-1e'>
                    <span className='couldve-made-apr'>
                      You could’ve made (in Apr 23)
                    </span>
                    <span className='rupees-1f'>₹13,10,71,515</span>
                  </div>
                </div>
              </div>
              <div className='container-20'>
                <div className='background-21'>
                  <div className='image-22' />
                  <div className='container-23'>
                    <div className='practo-logo-fb-svg'>
                      <div className='practo-logo-fb-svg-fill'>
                        <div className='practo-logo-fb-svg-24'>
                          <div className='clip-path-group-25' />
                        </div>
                      </div>
                    </div>
                    <div className='rectangle' />
                  </div>
                </div>
                <div className='background-26'>
                  <div className='practo-logo-fb-svg-27'>
                    <div className='practo-logo-fb-svg-fill-28'>
                      <div className='practo-logo-fb-svg-29'>
                        <div className='clip-path-group-2a' />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='container-2b'>
                <div className='background-2c'>
                  <div className='image-2d' />
                  <div className='container-2e'>
                    <div className='image-2f' />
                    <div className='rectangle-30' />
                  </div>
                </div>
                <div className='background-31'>
                  <div className='image-32' />
                </div>
              </div>
              <div className='container-33'>
                <div className='background-34'>
                  <div className='image-35' />
                  <div className='container-36'>
                    <div className='cred-logo-dc-svg'>
                      <div className='cred-logo-dc-svg-fill'>
                        <div className='cred-logo-dc-svg-37'>
                          <div className='vector-38' />
                        </div>
                      </div>
                    </div>
                    <div className='rectangle-39' />
                  </div>
                </div>
                <div className='background-3a'>
                  <div className='cred-logo-dc-svg-3b'>
                    <div className='cred-logo-dc-svg-fill-3c'>
                      <div className='cred-logo-dc-svg-3d'>
                        <div className='vector-3e' />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='container-3f'>
                <div className='background-40'>
                  <div className='image-41' />
                  <div className='container-42'>
                    <div className='blusmart-logo-cacaaa-svg'>
                      <div className='blusmart-logo-cacaaa-svg-fill'>
                        <div className='blusmart-logo-cacaaa-svg-43'>
                          <div className='clip-path-group-44'>
                            <div className='group'>
                              <div className='mask-group' />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className='rectangle-45' />
                  </div>
                </div>
                <div className='background-46'>
                  <div className='blusmart-logo-cacaaa-svg-47'>
                    <div className='blusmart-logo-cacaaa-svg-fill-48'>
                      <div className='blusmart-logo-cacaaa-svg-49'>
                        <div className='clip-path-group-4a'>
                          <div className='group-4b'>
                            <div className='mask-group-4c' />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='container-4d'>
                <div className='background-4e'>
                  <div className='image-4f' />
                  <div className='container-50'>
                    <div className='byjus-logo-svg'>
                      <div className='byjus-logo-svg-fill'>
                        <div className='byjus-logo-svg-51'>
                          <div className='clip-path-group-52' />
                        </div>
                      </div>
                    </div>
                    <span className='downhill-valuation-since-feb'>
                      Downhill valuation since Feb 16
                    </span>
                  </div>
                </div>
                <div className='background-53'>
                  <div className='byjus-logo-svg-54'>
                    <div className='byjus-logo-svg-fill-55'>
                      <div className='byjus-logo-svg-56'>
                        <div className='clip-path-group-57' />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='container-58'>
                <div className='background-59'>
                  <div className='image-5a' />
                  <div className='container-5b'>
                    <div className='image-5c' />
                    <span className='uphill-valuation'>
                      Uphill valuation since Jan 19
                    </span>
                  </div>
                </div>
                <div className='background-5d'>
                  <div className='image-5e' />
                </div>
              </div>
              <div className='container-5f'>
                <div className='background-60'>
                  <div className='image-61' />
                  <div className='container-62'>
                    <div className='swiggy-logo'>
                      <div className='swiggy-logo-fill'>
                        <div className='swiggy-logo-63'>
                          <div className='vector-64' />
                        </div>
                      </div>
                    </div>
                    <span className='uphill-valuation-65'>
                      Uphill valuation since Feb 15
                    </span>
                  </div>
                </div>
                <div className='background-66'>
                  <div className='swiggy-logo-67'>
                    <div className='swiggy-logo-fill-68'>
                      <div className='swiggy-logo-69'>
                        <div className='vector-6a' />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='container-6b'>
                <div className='background-6c'>
                  <div className='image-6d' />
                  <div className='container-6e'>
                    <div className='ola-logo'>
                      <div className='ola-logo-fill'>
                        <div className='ola-logo-6f'>
                          <div className='clip-path-group-70' />
                        </div>
                      </div>
                    </div>
                    <span className='downhill-valuation'>
                      Downhill valuation since Mar 15
                    </span>
                  </div>
                </div>
                <div className='background-71'>
                  <div className='ola-logo-72'>
                    <div className='ola-logo-fill-73'>
                      <div className='ola-logo-74'>
                        <div className='clip-path-group-75' />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='button'>
              <div className='arrow-up'>
                <div className='arrow-up-fill'>
                  <div className='arrow-up-76'>
                    <div className='vector-77' />
                  </div>
                </div>
              </div>
            </div>
            <div className='button-78'>
              <div className='arrow-up-79'>
                <div className='arrow-up-fill-7a'>
                  <div className='arrow-up-7b'>
                    <div className='vector-7c' />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='flex-row'>
            <span className='source'>Source: </span>
            <div className='tracxn-white'>
              <div className='tracxn-white-fill'>
                <div className='tracxn-white-7d'>
                  <div className='clip-path-group-7e'>
                    <div className='group-7f'>
                      <div className='vector-80' />
                      <div className='vector-81' />
                      <div className='vector-82' />
                      <div className='vector-83' />
                      <div className='vector-84' />
                      <div className='vector-85' />
                      <div className='vector-86' />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <span className='heading'>Check Out Our Live Campaigns</span>
        <div className='container-87'>
          <div className='background-border-shadow-88'>
            <div className='flex-row-89'>
              <div className='picture-image' />
              <span className='tranche'>Tranche 1</span>
            </div>
            <div className='picture-image-8a' />
            <div className='flex-row-8b'>
              <span className='heading-8c'>MOPP Foods</span>
              <div className='background-8d'>
                <span className='premium-series'>Premium Series</span>
              </div>
            </div>
            <div className='container-8e'>
              <span className='mopp-foods'>
                MOPP Foods is an internet-first brand that
                <br />
                operates 20 virtual restaurants from 5 cloud
                <br />
                kitchens with a portfolio of 4 brands - Mad Over…
                <br />
                Parathas & Pakodas (MOPP), Mealy, Sassy Indian,
              </span>
            </div>
            <div className='flex-row-8f'>
              <span className='funds-required'>Funds Required</span>
              <span className='minimum-investment'>Minimum Investment</span>
            </div>
            <div className='flex-row-90'>
              <div className='strong'>
                <span className='company-net-worth'>₹50,00,000</span>
              </div>
              <div className='strong-91'>
                <span className='text-25'>₹10,00,000</span>
              </div>
            </div>
            <span className='text-26'>Company Net worth</span>
            <div className='section-2c'>
              <span className='currency-amount'>₹25,00,00,000</span>
            </div>
            <div className='flex-row-bcb'>
              <span className='currency-amount-92'>₹50,00,000</span>
              <span className='percentage-amount'>100 % of ₹50,00,000</span>
            </div>
            <div className='background-93' />
            <div className='background-border-shadow-94'>
              <span className='completed'>Completed</span>
            </div>
          </div>
          <div className='background-border-shadow-95'>
            <div className='gameeon-logo'>
              <div className='gameeon-logo-fill'>
                <div className='gameeon-logo-96'>
                  <div className='vector-97' />
                </div>
              </div>
            </div>
            <div className='image-98' />
            <div className='flex-row-aa'>
              <span className='heading-gameeon-studios'>GameEon Studios</span>
              <div className='background-99'>
                <span className='premium-series-9a'>Premium Series</span>
              </div>
            </div>
            <div className='container-9b'>
              <span className='gameeon-studios-description'>
                GameEon Studios is a Mumbai-based Game
                <br />
                Development and Publishing company focused on
                <br />
                creating unique gaming experiences. With…
                <br />
                expertise in developing India’s first gaming IPs, the
              </span>
            </div>
            <div className='flex-row-daa'>
              <span className='funds-required-9c'>Funds Required</span>
              <span className='minimum-investment-9d'>Minimum Investment</span>
            </div>
            <div className='flex-row-dd-9e'>
              <div className='strong-9f'>
                <span className='currency-amount-a0'>₹1,00,00,000</span>
              </div>
              <div className='strong-a1'>
                <span className='currency-amount-a2'>₹25,00,000</span>
              </div>
            </div>
            <span className='company-net-worth-a3'>Company Net worth</span>
            <div className='strong-a4'>
              <span className='currency-amount-a5'>₹45,00,00,000</span>
            </div>
            <div className='flex-row-cad'>
              <span className='currency-amount-a6'>₹1,00,00,000</span>
              <span className='percentage-amount-a7'>
                100 % of ₹1,00,00,000
              </span>
            </div>
            <div className='background-a8' />
            <div className='background-border-shadow-a9'>
              <span className='completed-aa'>Completed</span>
            </div>
          </div>
          <div className='background-border-shadow-ab'>
            <div className='flex-row-af'>
              <div className='image-ac' />
              <span className='tranche-2'>Tranche 2</span>
            </div>
            <div className='image-ad' />
            <div className='flex-row-fe'>
              <span className='heading-mopp-foods'>MOPP Foods</span>
              <div className='background-ae'>
                <span className='premium-series-af'>Premium Series</span>
              </div>
            </div>
            <div className='container-b0'>
              <span className='mopp-foods-description'>
                MOPP Foods is an internet-first brand that
                <br />
                operates 20 virtual restaurants from 5 cloud
                <br />
                kitchens with a portfolio of 4 brands - Mad Over…
                <br />
                Parathas & Pakodas (MOPP), Mealy, Sassy Indian,
              </span>
            </div>
            <div className='flex-row-ef'>
              <span className='funds-required-b1'>Funds Required</span>
              <span className='minimum-investment-b2'>Minimum Investment</span>
            </div>
            <div className='flex-row-ebb'>
              <div className='strong-b3'>
                <span className='currency-amount-b4'>₹1,00,00,000</span>
              </div>
              <div className='strong-b5'>
                <span className='currency-amount-b6'>₹10,00,000</span>
              </div>
            </div>
            <span className='company-net-worth-b7'>Company Net worth</span>
            <div className='strong-b8'>
              <span className='currency-amount-b9'>₹25,00,00,000</span>
            </div>
            <div className='flex-row-ad'>
              <span className='currency-amount-ba'>₹0</span>
              <span className='percentage-amount-bb'>0 % of ₹1,00,00,000</span>
            </div>
            <div className='background-bc' />
            <div className='flex-row-a'>
              <div className='link-bd'>
                <span className='invest-now'>Invest now</span>
                <div className='image-be'>
                  <div className='icon-arrow-right-black-fill'>
                    <div className='icon-arrow-right-black'>
                      <div className='clip-path-group-bf'>
                        <div className='group-c0'>
                          <div className='vector-c1' />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <span className='closes-on'>Closes on</span>
            </div>
            <span className='closes-on-date'>Oct 21st 2024</span>
          </div>
          <div className='background-border-shadow-c2'>
            <div className='image-c3' />
            <div className='image-c4' />
            <div className='flex-row-d-c5'>
              <span className='heading-the-hobby-tribe'>The Hobby Tribe</span>
              <div className='background-c6'>
                <span className='premium-series-c7'>Premium Series</span>
              </div>
            </div>
            <div className='container-c8'>
              <span className='hobby-tribe-app'>
                The Hobby Tribe India's first of its kind FREE app
                <br />
                that engages people based on their favourite
                <br />
                hobbies like guitar, cooking, sports, art etc. by…
                <br />
                incentivising users to complete hobby based
              </span>
            </div>
            <div className='flex-row-c'>
              <span className='funds-required-c9'>Funds Required</span>
              <span className='min-investment'>Minimum Investment</span>
            </div>
            <div className='flex-row-a-ca'>
              <div className='strong-cb'>
                <span className='company-net-worth-cc'>₹1,50,00,000</span>
              </div>
              <div className='strong-cd'>
                <span className='company-net-worth-ce'>₹5,00,000</span>
              </div>
            </div>
            <span className='company-net-worth-cf'>Company Net worth</span>
            <div className='strong-d0'>
              <span className='company-net-worth-d1'>₹17,00,00,000</span>
            </div>
            <div className='flex-row-ccd'>
              <span className='min-investment-d2'>₹30,00,000</span>
              <span className='percent-of-funds'>20 % of ₹1,50,00,000</span>
            </div>
            <div className='flex-row-df'>
              <div className='background-d3' />
              <div className='background-d4' />
            </div>
            <div className='flex-row-cc'>
              <div className='link-d5'>
                <span className='invest-now-d6'>Invest now</span>
                <div className='image-d7'>
                  <div className='icon-arrow-right'>
                    <div className='icon-arrow-right-d8'>
                      <div className='clip-path-group-d9'>
                        <div className='group-da'>
                          <div className='vector-db' />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <span className='closes-on-dc'>Closes on</span>
            </div>
            <span className='closes-on-dd'>Oct 21st 2024</span>
          </div>
          <div className='background-border-shadow-de'>
            <div className='blur'>
              <div className='tech-logo'>
                <div className='tech-logo-df'>
                  <div className='tech-logo-e0'>
                    <div className='vector-e1' />
                  </div>
                </div>
              </div>
              <div className='image-e2' />
              <div className='flex-row-e3'>
                <span className='misscallpay'>Misscallpay</span>
                <div className='background-e4'>
                  <span className='premium-series-e5'>Premium Series</span>
                </div>
              </div>
              <div className='container-e6'>
                <span className='lorem-ipsum'>
                  Lorem ipsum dolor set lorem ipsum dolor set lorem
                  <br />
                  ipsum dolor set Lorem ipsum dolor set lorem ipsum
                  <br />
                  set
                </span>
              </div>
              <div className='flex-row-c-e7'>
                <span className='funds-required-e8'>Funds Required</span>
                <span className='min-investment-e9'>Minimum Investment</span>
              </div>
              <div className='flex-row-c-ea'>
                <div className='strong-eb'>
                  <span className='company-net-worth-ec'>₹50,00,000</span>
                </div>
                <div className='strong-ed'>
                  <span className='company-net-worth-ee'>₹10,00,000</span>
                </div>
              </div>
              <span className='company-net-worth-ef'>Company Net worth</span>
              <div className='strong-f0'>
                <span className='company-net-worth-f1'>₹25,00,00,000</span>
              </div>
              <div className='flex-row-bca'>
                <span className='min-investment-f2'>₹0</span>
                <span className='percent-of-funds-f3'>0 % of ₹50,00,000</span>
              </div>
              <div className='background-f4' />
              <div className='link-f5'>
                <span className='invest-now-f6'>Invest now</span>
                <div className='image-f7'>
                  <div className='icon-arrow-right-f8'>
                    <div className='icon-arrow-right-f9'>
                      <div className='clip-path-group-fa'>
                        <div className='group-fb'>
                          <div className='vector-fc' />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='coming-soon'>
              <div className='coming-soon-fd'>
                <div className='coming-soon-fe' />
              </div>
            </div>
          </div>
          <div className='background-border-shadow-ff'>
            <div className='blur-100'>
              <div className='gameeon-logo-101'>
                <div className='gameeon-logo-102'>
                  <div className='gameeon-logo-103'>
                    <div className='vector-104' />
                  </div>
                </div>
              </div>
              <div className='image-105' />
              <div className='flex-row-af-106'>
                <span className='blue-tea'>Blue Tea</span>
                <div className='background-107'>
                  <span className='premium-series-108'>Premium Series</span>
                </div>
              </div>
              <div className='container-109'>
                <span className='lorem-ipsum-dolor'>
                  Lorem ipsum dolor set lorem ipsum dolor set lorem
                  <br />
                  ipsum dolor set Lorem ipsum dolor set lorem ipsum
                  <br />
                  set
                </span>
              </div>
              <div className='flex-row-efe'>
                <span className='funds-required-10a'>Funds Required</span>
                <span className='minimum-investment-10b'>
                  Minimum Investment
                </span>
              </div>
              <div className='flex-row-bcb-10c'>
                <div className='strong-10d'>
                  <span className='rupees-5000000'>₹50,00,000</span>
                </div>
                <div className='strong-10e'>
                  <span className='rupees-1000000'>₹10,00,000</span>
                </div>
              </div>
              <span className='company-net-worth-10f'>Company Net worth</span>
              <div className='strong-110'>
                <span className='rupees-25000000'>₹25,00,00,000</span>
              </div>
              <div className='flex-row-ec'>
                <span className='rupees-0'>₹0</span>
                <span className='percentage-0-of-rupees-5000000'>
                  0 % of ₹50,00,000
                </span>
              </div>
              <div className='background-111' />
              <div className='link-112'>
                <span className='invest-now-113'>Invest now</span>
                <div className='image-114'>
                  <div className='icon-arrow-right-black-fill-115'>
                    <div className='icon-arrow-right-black-116'>
                      <div className='clip-path-group-117'>
                        <div className='group-118'>
                          <div className='vector-119' />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='coming-soon-eab-svg'>
              <div className='coming-soon-eab-svg-fill'>
                <div className='coming-soon-eab-svg-11a' />
              </div>
            </div>
          </div>
        </div>
        <div className='link-11b'>
          <span className='see-campaigns'>See campaigns</span>
          <div className='arrow-up-lg-e' />
        </div>
        <div className='section-11c'>
          <div className='pathway-to-back-innovative-startups'>
            <span className='pathway-to-back'>Pathway to Back </span>
            <span className='innovative-startups'>Innovative Startups</span>
          </div>
          <div className='flex-row-fe-11d'>
            <div className='background-border'>
              <div className='picture-step-investor-ed-svg'>
                <div className='step-investor-ed-svg-fill'>
                  <div className='step-investor-ed-svg'>
                    <div className='clip-path-group-11e'>
                      <div className='group-11f'>
                        <div className='vector-120' />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='icon-line-cae'>
              <div className='icon-line-cae-121'>
                <div className='vector-122' />
              </div>
            </div>
            <div className='background-border-123'>
              <div className='picture-step-investor-ee'>
                <div className='step-investor-ee'>
                  <div className='step-investor-ee-124' />
                </div>
              </div>
            </div>
            <div className='icon-line-cae-125'>
              <div className='icon-line-cae-126'>
                <div className='vector-127' />
              </div>
            </div>
            <div className='background-border-128'>
              <div className='picture-step-investor-eace'>
                <div className='step-investor-eace'>
                  <div className='step-investor-eace-129' />
                </div>
              </div>
            </div>
          </div>
          <div className='flex-row-e'>
            <span className='heading-step'>Step 1</span>
            <span className='heading-step-12a'>Step 2</span>
            <span className='heading-step-12b'>Step 3</span>
          </div>
          <div className='flex-row-b-12c'>
            <span className='access-live-campaigns'>
              Access to Live Campaigns
            </span>
            <span className='participate-campaigns'>
              Participate in Campaigns
            </span>
            <span className='digital-kyc-registration'>
              Digital KYC for
              <br />
              Registration
            </span>
          </div>
          <div className='flex-row-eb'>
            <div className='background-border-12d'>
              <div className='picture-step-investor-aaa'>
                <div className='step-investor-aaa'>
                  <div className='step-investor-aaa-12e'>
                    <div className='vector-12f' />
                  </div>
                </div>
              </div>
            </div>
            <div className='icon-line-cae-130'>
              <div className='icon-line-cae-131'>
                <div className='vector-132' />
              </div>
            </div>
            <div className='background-border-133'>
              <div className='picture-step-investor'>
                <div className='step-investor'>
                  <div className='step-investor-134' />
                </div>
              </div>
            </div>
          </div>
          <div className='flex-row-ca'>
            <span className='heading-step-135'>Step 4</span>
            <span className='heading-step-136'>Step 5</span>
          </div>
          <div className='flex-row-e-137'>
            <span className='sign-agreement-digitally'>
              Sign Agreement Digitally
            </span>
            <span className='access-startup-profiles'>
              Access to Updated Startup
              <br />
              Profiles
            </span>
          </div>
          <div className='link-button-138'>
            <span className='invest-now-139'>Invest Now</span>
          </div>
        </div>
        <span className='product-offerings'>Our Product Offerings</span>
        <div className='container-13a'>
          <div className='paragraph-background-border'>
            <span className='csop'>CSOP</span>
            <span className='community-subscription-pool'>
              
              (Community Subscription Offer Pool)
            </span>
          </div>
          <div className='paragraph-background-border-13b'>
            <span className='aif'>AIF</span>
            <span className='alternative-investment-funds'>
              
              (Alternative Investment Funds)
            </span>
          </div>
          <div className='venture-debt'>
            <span className='background-border-13c'>Venture Debt</span>
          </div>
        </div>
        <div className='paragraph-background-border-shadow'>
          <span className='csop-13d'>CSOP</span>
          <span className='community-subscription-pool-13e'>
            Community Subscription Offer Pool
          </span>
          <span className='csop-description'>
            At Creddinv, we offer a unique investment opportunity known as a
            CSOP, or Community Subscription Offer Pool. Through this contractual
            agreement, subscribers gain access
            <br />
            to exclusive community benefits while also having the potential to
            receive Stock Appreciation Rights (SARs).
          </span>
          <span className='csop-benefits'>
            With a CSOP from Creddinv, investors can participate in the growth
            and success of innovative startups while enjoying a range of
            community privileges.
          </span>
          <span className='fair-exits'>
            Benefits:
            <br />
            Fair Exits: Exits occur at Fair Market Value with a guaranteed
            minimum based on entry value multiples, ensuring better protection
            compared to options without a floor.
          </span>
          <span className='increased-liquidity'>
            Increased Liquidity: Staggered cash settlements provide subscribers
            with an attractive liquidity option, addressing a major pain point
            in traditional Angel Investing.
          </span>
          <span className='high-returns'>
            Potential for High Returns: CSOPs are linked to the company's
            equity, so if the company's valuation increases tenfold, the value
            of the CSOPs will also grow proportionally.
          </span>
        </div>
        <div className='section-13f'>
          <div className='container-140'>
            <div className='picture-image-141' />
            <div className='overlay' />
          </div>
          <div className='container-142'>
            <span className='exciting-news'>Exciting News!</span>
            <div className='heading-143'>
              <div className='investor-app-coming-soon'>
                <span className='our'>Our </span>
                <span className='investor-app'>Investor App</span>
                <span className='coming-soon-144'> </span>
                <span className='stay-tuned'>is Coming Soon.</span>
              </div>
            </div>
            <span className='access-on'>
              Stay Tuned for Seamless Investment. Access on -
            </span>
            <div className='flex-row-aaf'>
              <div className='link-145'>
                <div className='icon-google-play-dc'>
                  <div className='icon-google-play-dc-fill'>
                    <div className='icon-google-play-dc-146'>
                      <div className='group-147'>
                        <div className='vector-148' />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='link-149'>
                <div className='icon-apple-store'>
                  <div className='icon-apple-store-fill'>
                    <div className='icon-apple-store-14a' />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <span className='heading-frequently-asked-questions'>
          Frequently Asked Questions
        </span>
        <div className='background-14b'>
          <div className='background-14c'>
            <div className='heading-link'>
              <span className='investment-opportunities'>
                1. What types of investment opportunities does CREDDINV offer to
                investors?
              </span>
              <div className='image-14d'>
                <div className='icon-plus-sign-fill'>
                  <div className='icon-plus-sign'>
                    <div className='group-14e' />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='background-14f'>
            <div className='heading-link-150'>
              <span className='source-and-vet-opportunities'>
                2. How does CREDDINV source and vet potential investment
                opportunities?
              </span>
              <div className='image-151'>
                <div className='icon-plus-sign-fill-152'>
                  <div className='icon-plus-sign-153'>
                    <div className='group-154' />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='background-155'>
            <div className='heading-link-156'>
              <span className='expected-return-on-investment'>
                3. What is the expected return on investment for CREDDINV's
                investment opportunities?
              </span>
              <div className='image-157'>
                <div className='icon-plus-sign-fill-158'>
                  <div className='icon-plus-sign-159'>
                    <div className='group-15a' />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='background-15b'>
            <div className='heading-link-15c'>
              <span className='updates-or-reporting'>
                4. Does CREDDINV provide regular updates or reporting on
                investment performance to investors?
              </span>
              <div className='image-15d'>
                <div className='icon-plus-sign-fill-15e'>
                  <div className='icon-plus-sign-15f'>
                    <div className='group-160' />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='background-161'>
            <div className='heading-link-162'>
              <span className='success-stories-case-studies'>
                5. What success stories or case studies can CREDDINV share of
                successful investments?
              </span>
              <div className='image-163'>
                <div className='icon-plus-sign-fill-164'>
                  <div className='icon-plus-sign-165'>
                    <div className='group-166' />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='footer'>
          <div className='flex-row-bd'>
            <span className='invest-167'>Invest</span>
            <span className='learn-168'>Learn</span>
            <span className='company'>Company</span>
            <span className='contact-us'>Contact Us</span>
            <span className='registered-office'>Registered office</span>
          </div>
          <div className='flex-row-b-169'>
            <span className='th-floor-jai-hind-estate'>
              5th Floor, 3-A Jai Hind Estate, Dr.
              <br />
              Atmaram Merchant Road
              <br />
              Bhuleshwar, Kalbadevi,
              <br />
              Mumbai - 400002
              <br />
              CIN U74999MH2021PTC353592
            </span>
            <div className='link-invoice-discounting'>
              <span className='invoice-discounting'>Invoice Discounting</span>
            </div>
            <span className='link-blog'>Blog</span>
            <span className='link-about-us'>About us</span>
            <span className='link-support-tykeinvest-com'>
              support@tykeinvest.com
            </span>
            <div className='link-wealth'>
              <span className='wealth'>Wealth</span>
            </div>
            <div className='link-learn'>
              <span className='learn-16a'>Learn</span>
            </div>
            <span className='link-91-8447748631'>+91-8447748631</span>
          </div>
          <span className='follow-us'>Follow Us</span>
          <div className='flex-row-cb'>
            <div className='link-facebook-logo-square' />
            <div className='link-linkedin-logo' />
            <div className='link-instagram-logo' />
          </div>
          <div className='separator' />
          <div className='section-16b'>
            <span className='link-privacy-policy'>Privacy Policy</span>
            <div className='link-risk-of-investment'>
              <span className='risk-of-investment'>Risk Of Investment</span>
            </div>
            <span className='link-terms-and-conditions'>
              Terms and Conditions
            </span>
            <div className='link-disclaimer'>
              <span className='disclaimer'>Disclaimer</span>
            </div>
            <span className='tyke-technologies-pvt-ltd-all-rights-reserved'>
              Tyke Technologies Pvt Ltd • 2024 All Rights Reserved
            </span>
          </div>
          <div className='separator-16c' />
          <div className='section-16d'>
            <span className='disclaimer-16e'>Disclaimer :</span>
            <span className='all-trademarks-and-logos'>
              All trademarks and logos or registered trademarks and logos found
              on this site or mentioned herein belong to their respective owners
              and are solely being used for informational purposes. Information
              <br />
              provided herein has been gathered from public sources. Tyke
              Technologies Pvt Ltd disclaims any and all responsibility in
              connection with veracity of this data. Information presented on
              this website is for
              <br />
              educational purposes only and should not be treated as legal,
              financial , or any other form of advice. Tyke Technologies Pvt Ltd
              is not liable for financial or any other form of loss incurred by
              the user or any
              <br />
              affiliated party on the basis of information provided herein. Tyke
              Technologies Pvt Ltd is neither a stock exchange nor does it
              intend to get recognized as a stock exchange under the Securities
              Contracts
              <br />
              Regulation Act, 1956. Tyke Technologies Pvt Ltd has not been
              authorized by the capital markets regulator to solicit
              investments. Tyke also provides that it does not facilitate any
              online or offline buying,
              <br />
              selling, or trading of securities. Tyke Technologies Pvt Ltd has
              partnered with regulated entities as channel partner to distribute
              their products on it's platform.
            </span>
            <span className='this-site-will-be-updated'>
              This Site will be updated on a regular basis.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
